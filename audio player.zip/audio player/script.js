// HTML elements ko select karein
const audio = document.getElementById('audio-element');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const title = document.getElementById('song-title');
const artist = document.getElementById('artist-name');
const cover = document.getElementById('cover-art');
const progressContainer = document.getElementById('progress-container');
const progressBar = document.getElementById('progress-bar');
const currentTimeEl = document.getElementById('current-time');
const durationTimeEl = document.getElementById('duration-time');
const volumeSlider = document.getElementById('volume-slider');
const songList = document.getElementById('song-list');
const recentlyPlayedList = document.getElementById('recently-played-list');

const playBarBtn = document.getElementById('play-bar');
const prevBarBtn = document.getElementById('prev-bar');
const nextBarBtn = document.getElementById('next-bar');
const currentCoverEl = document.getElementById('current-cover');
const currentTitleEl = document.getElementById('current-title');
const currentArtistEl = document.getElementById('current-artist');

const loginBtn = document.getElementById('login-btn');
const signupBtn = document.getElementById('signup-btn');
const greetingEl = document.getElementById('greeting');
const searchInput = document.getElementById('search-input');
const themeToggleBtn = document.getElementById('theme-toggle-btn');
const themeIcon = document.getElementById('theme-icon');

const shuffleBtn = document.getElementById('shuffle');
const repeatBtn = document.getElementById('repeat');
const playAllBtn = document.getElementById('play-all-btn');

// Gaanon ki list (array of objects)
const allSongs = [
    {
        title: 'Latest Song 1',
        artist: 'Artist Name A',
        name: 'song1.mp3',
        cover: 'cover1.jpg',
        liked: false
    },
    {
        title: 'Song Title 2',
        artist: 'Artist Name B',
        name: 'song2.mp3',
        cover: 'cover2.jpg',
        liked: true
    },
    {
        title: 'Latest Song 3',
        artist: 'Artist Name C',
        name: 'song3.mp3',
        cover: 'cover3.jpg',
        liked: false
    }
];

let songs = [...allSongs];
let recentlyPlayedSongs = [];
let isPlaying = false;
let isShuffling = false;
let isRepeating = false;
let songIndex = 0;
let isDragging = false; // NEW: Drag state variable

function renderPlaylist() {
    songList.innerHTML = '';
    songs.forEach((song, index) => {
        const listItem = createSongListItem(song, index, true);
        songList.appendChild(listItem);
    });
}

// NEW: Function to render recently played songs
function renderRecentlyPlayed() {
    recentlyPlayedList.innerHTML = '';
    recentlyPlayedSongs.forEach((song, index) => {
        const listItem = createSongListItem(song, index, false);
        recentlyPlayedList.appendChild(listItem);
    });
}

function createSongListItem(song, index, isMainPlaylist) {
    const listItem = document.createElement('li');
    listItem.classList.add('song-item');
    listItem.setAttribute('data-index', index);
    
    listItem.innerHTML = `
        <div class="song-details">
            <p class="title">${song.title}</p>
            <p class="artist">${song.artist}</p>
        </div>
        <i class="far fa-heart like-btn ${song.liked ? 'fas liked' : ''}"></i>
    `;

    listItem.addEventListener('click', (e) => {
        if (!e.target.classList.contains('like-btn')) {
            if (isMainPlaylist) {
                songIndex = index;
                loadSong(songs[songIndex]);
            } else {
                // Handle click from recently played list
                const songFromRecent = recentlyPlayedSongs[index];
                const originalIndex = allSongs.findIndex(s => s.name === songFromRecent.name);
                songIndex = originalIndex;
                loadSong(allSongs[songIndex]);
            }
            playSong();
        }
    });
    
    const likeBtn = listItem.querySelector('.like-btn');
    likeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (isMainPlaylist) {
            songs[index].liked = !songs[index].liked;
        } else {
            const originalIndex = allSongs.findIndex(s => s.name === recentlyPlayedSongs[index].name);
            allSongs[originalIndex].liked = !allSongs[originalIndex].liked;
            recentlyPlayedSongs[index].liked = !recentlyPlayedSongs[index].liked;
        }
        likeBtn.classList.toggle('fas');
        likeBtn.classList.toggle('liked');
    });

    return listItem;
}

// NEW: Add song to recently played list
function addToRecentlyPlayed(song) {
    // Check if the song is already the most recent one
    if (recentlyPlayedSongs[0] && recentlyPlayedSongs[0].name === song.name) {
        return;
    }
    
    // Remove if song exists in the list
    const existingIndex = recentlyPlayedSongs.findIndex(s => s.name === song.name);
    if (existingIndex !== -1) {
        recentlyPlayedSongs.splice(existingIndex, 1);
    }

    recentlyPlayedSongs.unshift(song); // Add to the beginning
    if (recentlyPlayedSongs.length > 5) { // Keep the list to a maximum of 5 songs
        recentlyPlayedSongs.pop();
    }
    renderRecentlyPlayed();
}

// Search functionality
searchInput.addEventListener('keyup', (e) => {
    const searchTerm = e.target.value.toLowerCase();
    const filteredSongs = allSongs.filter(song => {
        return song.title.toLowerCase().includes(searchTerm) || song.artist.toLowerCase().includes(searchTerm);
    });
    songs = filteredSongs;
    renderPlaylist();
});

// Dark mode functionality
themeToggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    if (document.body.classList.contains('light-mode')) {
        localStorage.setItem('theme', 'light');
        themeIcon.classList.replace('fa-moon', 'fa-sun');
    } else {
        localStorage.setItem('theme', 'dark');
        themeIcon.classList.replace('fa-sun', 'fa-moon');
    }
});

function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-mode');
        themeIcon.classList.replace('fa-moon', 'fa-sun');
    }
}

function setGreeting() {
    const hour = new Date().getHours();
    let greetingText = '';
    if (hour < 12) {
        greetingText = 'Good morning!';
    } else if (hour < 18) {
        greetingText = 'Good afternoon!';
    } else {
        greetingText = 'Good evening!';
    }
    greetingEl.textContent = greetingText;
}

loginBtn.addEventListener('click', () => {
    alert('Log In functionality will be added with a backend server.');
});

signupBtn.addEventListener('click', () => {
    alert('Sign Up functionality will be added with a backend server.');
});

function playSong() {
    isPlaying = true;
    playBtn.classList.replace('fa-play', 'fa-pause');
    playBarBtn.classList.replace('fa-play', 'fa-pause');
    audio.play();
}

function pauseSong() {
    isPlaying = false;
    playBtn.classList.replace('fa-pause', 'fa-play');
    playBarBtn.classList.replace('fa-pause', 'fa-play');
    audio.pause();
}

function loadSong(song) {
    title.textContent = song.title;
    artist.textContent = song.artist;
    audio.src = `audio/${song.name}`;
    cover.src = `images/${song.cover}`;

    currentTitleEl.textContent = song.title;
    currentArtistEl.textContent = song.artist;
    currentCoverEl.src = `images/${song.cover}`;
    
    // NEW: Add song to recently played list when it loads
    addToRecentlyPlayed(song);
}

function nextSong() {
    songIndex = (songIndex + 1) % songs.length;
    loadSong(songs[songIndex]);
    playSong();
}

function prevSong() {
    songIndex = (songIndex - 1 + songs.length) % songs.length;
    loadSong(songs[songIndex]);
    playSong();
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

playBtn.addEventListener('click', () => isPlaying ? pauseSong() : playSong());
playBarBtn.addEventListener('click', () => isPlaying ? pauseSong() : playSong());

nextBtn.addEventListener('click', nextSong);
nextBarBtn.addEventListener('click', nextSong);

prevBtn.addEventListener('click', prevSong);
prevBarBtn.addEventListener('click', prevSong);

shuffleBtn.addEventListener('click', () => {
    isShuffling = !isShuffling;
    shuffleBtn.classList.toggle('active', isShuffling);
    if (isShuffling) {
        shuffleArray(songs);
        renderPlaylist();
    } else {
        songs = [...allSongs];
        renderPlaylist();
    }
});

repeatBtn.addEventListener('click', () => {
    isRepeating = !isRepeating;
    repeatBtn.classList.toggle('active', isRepeating);
});

playAllBtn.addEventListener('click', () => {
    songIndex = 0;
    loadSong(songs[songIndex]);
    playSong();
});

audio.addEventListener('timeupdate', (e) => {
    if (!isDragging) { // Only update progress bar if not dragging
        const { duration, currentTime } = e.target;
        const progressPercent = (currentTime / duration) * 100;
        progressBar.style.width = `${progressPercent}%`;

        const minutes = Math.floor(currentTime / 60);
        const seconds = Math.floor(currentTime % 60);
        currentTimeEl.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        if (duration) {
            const durMinutes = Math.floor(duration / 60);
            const durSeconds = Math.floor(duration % 60);
            durationTimeEl.textContent = `${durMinutes}:${durSeconds < 10 ? '0' : ''}${durSeconds}`;
        }
    }
});

// NEW: Drag and drop functionality for progress bar
function setProgress(e) {
    const width = progressContainer.clientWidth;
    const clickX = e.offsetX;
    const duration = audio.duration;
    audio.currentTime = (clickX / width) * duration;
}

progressContainer.addEventListener('mousedown', (e) => {
    isDragging = true;
    setProgress(e);
});

document.addEventListener('mouseup', () => {
    isDragging = false;
});

document.addEventListener('mousemove', (e) => {
    if (isDragging) {
        const rect = progressContainer.getBoundingClientRect();
        const offsetX = e.clientX - rect.left;
        const width = progressContainer.clientWidth;
        const duration = audio.duration;
        audio.currentTime = (offsetX / width) * duration;
    }
});

// For simple click on progress bar
progressContainer.addEventListener('click', (e) => {
    setProgress(e);
});

volumeSlider.addEventListener('input', () => {
    audio.volume = volumeSlider.value;
});

audio.addEventListener('ended', () => {
    if (isRepeating) {
        audio.currentTime = 0;
        playSong();
    } else {
        nextSong();
    }
});

applySavedTheme();
setGreeting();
renderPlaylist();
loadSong(songs[songIndex]);
audio.volume = volumeSlider.value;