
document.getElementById("ageForm").addEventListener("submit", function(event) {
    event.preventDefault(); 

    
    let dobValue = document.getElementById("dob").value;
    let result = document.getElementById("result");


    if (!dobValue) {
        result.textContent = "⚠ Please select your Date of Birth!";
        result.style.display = "block";
        return;
    }

    
    let dob = new Date(dobValue);
    let today = new Date();

    
    if (dob > today) {
        result.textContent = "⚠ Date of Birth cannot be in the future!";
        result.style.display = "block";
        return;
    }
    let years = today.getFullYear() - dob.getFullYear();
    let months = today.getMonth() - dob.getMonth();
    let days = today.getDate() - dob.getDate()

    if (days < 0) {
        months--;
        let daysInPrevMonth = new Date(today.getFullYear(), today.getMonth(), 0).getDate();
        days += daysInPrevMonth;
    }

    
    if (months < 0) {
        years--;
        months += 12;
    }

    result.textContent = "🎉 you are " + years + " years, " + months + " months , and " + days + " days old.";
    result.style.display = "block";
});